
class ExampleEntity:
    def __init__(self, id, name, team, employeeCode):
        self.id = id
        self.name = name
        self.team = team
        self.employeeCode = employeeCode