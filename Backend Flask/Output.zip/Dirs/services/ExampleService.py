
class ExampleService:
    def getAllExample(self):
        # code to get all examples
        pass

    def saveExample(self, exampleEntity):
        # code to save example
        pass