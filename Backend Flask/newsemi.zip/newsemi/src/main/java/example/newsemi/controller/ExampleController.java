package example.newsemi.controller;


import example.newsemi.entity.ExampleEntity;
import example.newsemi.service.ExampleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ExampleController {
    
    @Autowired
    ExampleService exampleService;
    
    @GetMapping("/getAllExample")
    public List<ExampleEntity> getAllExample(){
        return exampleService.getAllExample();
    }

    @PostMapping("/saveExample")
    public ExampleEntity saveExample(@RequestBody ExampleEntity exampleEntity){
        return exampleService.saveExample(exampleEntity);
    }
}
