package example.newsemi.service;

import example.newsemi.entity.ExampleEntity;
import example.newsemi.repository.ExampleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExampleServiceImpl implements ExampleService {
    @Autowired
    ExampleRepository exampleRepository;


    @Override
    public List<ExampleEntity> getAllExample() {
        return exampleRepository.findAll();
    }

    @Override
    public ExampleEntity saveExample(ExampleEntity exampleEntity) {
        return exampleRepository.save(exampleEntity);
    }
}
