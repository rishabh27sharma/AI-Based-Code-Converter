package example.newsemi.service;

import example.newsemi.entity.ExampleEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ExampleService {
    List<ExampleEntity> getAllExample();

    ExampleEntity saveExample(ExampleEntity exampleEntity);
}
