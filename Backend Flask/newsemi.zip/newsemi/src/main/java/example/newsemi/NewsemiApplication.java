package example.newsemi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsemiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsemiApplication.class, args);
	}

}
